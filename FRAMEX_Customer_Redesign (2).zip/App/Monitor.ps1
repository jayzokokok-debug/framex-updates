param([string]$Out)
# FRAMEX live sensor service. Writes one key=value snapshot every ~1s for the panel.
$ErrorActionPreference = 'SilentlyContinue'
[Threading.Thread]::CurrentThread.CurrentCulture = [Globalization.CultureInfo]::InvariantCulture
$tmpf = "$Out.tmp"

function N($v) { if ($v -eq $null) { return '' } return ([string]$v).Trim() }

$cpuI = Get-CimInstance Win32_Processor | Select-Object -First 1
$cpuName = (N $cpuI.Name) -replace '\s+', ' '
$maxClk = [int]$cpuI.MaxClockSpeed
$nCores = [int]$cpuI.NumberOfCores
$nThr = [int]$cpuI.NumberOfLogicalProcessors
$gpus = @(Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch 'Basic|Remote|Virtual|Meta|Parsec|Mirage' })
$gpuI = $gpus | Where-Object { $_.Name -match 'NVIDIA|Radeon RX|Radeon Pro|Arc' } | Select-Object -First 1
if (-not $gpuI) { $gpuI = $gpus | Select-Object -First 1 }
$gpuName = N $gpuI.Name

$smi = $null
$cmd = Get-Command nvidia-smi.exe
if ($cmd) { $smi = $cmd.Source }
if (-not $smi) {
  foreach ($p in @("$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe", "$env:SystemRoot\System32\nvidia-smi.exe")) { if (Test-Path $p) { $smi = $p; break } }
}
$ping = New-Object Net.NetworkInformation.Ping
$pingMs = -1
$diskT = ''
$acpi = ''
$loop = 0

while ($true) {
  if (-not (Get-Process mshta)) { break }
  $o = New-Object System.Collections.Generic.List[string]
  $o.Add('ts=' + [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
  $o.Add("cpu.name=$cpuName"); $o.Add("cpu.threads=$nThr"); $o.Add("cpu.cores_phys=$nCores")

  # ---- CPU load (total + per thread) ----
  $pr = @(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor)
  $tot = $pr | Where-Object { $_.Name -eq '_Total' } | Select-Object -First 1
  if ($tot) { $o.Add('cpu.load=' + $tot.PercentProcessorTime) }
  $per = $pr | Where-Object { $_.Name -ne '_Total' } | Sort-Object { [int](($_.Name -split ',')[-1]) }
  $o.Add('cpu.per=' + (($per | ForEach-Object { $_.PercentProcessorTime }) -join ','))
  $pi = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'"
  $clk = 0
  if ($pi -and $pi.ProcessorFrequency -gt 0 -and $pi.PercentProcessorPerformance -gt 0) { $clk = [int]($pi.ProcessorFrequency * $pi.PercentProcessorPerformance / 100) }
  if ($clk -le 0) { $clk = [int](Get-CimInstance Win32_Processor | Select-Object -First 1).CurrentClockSpeed }
  $o.Add("cpu.clock=$clk"); $o.Add("cpu.max=$maxClk")

  # ---- RAM / system ----
  $os = Get-CimInstance Win32_OperatingSystem
  if ($os) {
    $o.Add('ram.total=' + [int]($os.TotalVisibleMemorySize / 1024))
    $o.Add('ram.free=' + [int]($os.FreePhysicalMemory / 1024))
  }
  $sys = Get-CimInstance Win32_PerfFormattedData_PerfOS_System
  if ($sys) { $o.Add('sys.procs=' + $sys.Processes); $o.Add('sys.up=' + $sys.SystemUpTime) }

  # ---- Disk activity ----
  $pd = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'"
  if ($pd) {
    $a = [int]$pd.PercentDiskTime; if ($a -gt 100) { $a = 100 }
    $o.Add("disk.act=$a"); $o.Add('disk.read=' + $pd.DiskReadBytesPersec); $o.Add('disk.write=' + $pd.DiskWriteBytesPersec)
  }
  $i = 0
  foreach ($d in (Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')) {
    $o.Add("disk.$i=" + $d.DeviceID + '|' + [int64]$d.Size + '|' + [int64]$d.FreeSpace); $i++
  }

  # ---- Network ----
  $rx = 0; $tx = 0
  foreach ($n in (Get-CimInstance Win32_PerfFormattedData_Tcpip_NetworkInterface)) {
    if ($n.Name -match 'Loopback|isatap|Teredo|6to4|Pseudo|Virtual|VMware|Hyper-V|vEthernet|Bluetooth|WAN Miniport') { continue }
    $rx += [double]$n.BytesReceivedPersec; $tx += [double]$n.BytesSentPersec
  }
  $o.Add("net.down=$rx"); $o.Add("net.up=$tx")
  if ($loop % 4 -eq 0) {
    try { $r = $ping.Send('1.1.1.1', 700); if ($r.Status -eq 'Success') { $pingMs = [int]$r.RoundtripTime } else { $pingMs = -1 } } catch { $pingMs = -1 }
  }
  $o.Add("net.ping=$pingMs")

  # ---- GPU ----
  $o.Add("gpu.name=$gpuName")
  $done = $false
  if ($smi -and ($gpuName -match 'NVIDIA' -or -not $gpuName)) {
    $line = & $smi --query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total,power.draw,clocks.gr,fan.speed --format=csv,noheader,nounits 2>$null | Select-Object -First 1
    if ($line) {
      $f = ($line -split ',') | ForEach-Object { $_.Trim() }
      if ($f.Count -ge 7) {
        $o.Add('gpu.load=' + $f[0]); $o.Add('gpu.temp=' + $f[1]); $o.Add('gpu.vramused=' + $f[2]); $o.Add('gpu.vramtotal=' + $f[3])
        $o.Add('gpu.power=' + $f[4]); $o.Add('gpu.clock=' + $f[5]); $o.Add('gpu.fan=' + $f[6]); $done = $true
      }
    }
  }
  if (-not $done) {
    $eng = @(Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine | Where-Object { $_.Name -like '*engtype_3D*' })
    if ($eng.Count) {
      $best = 0
      $eng | Group-Object { if ($_.Name -match 'luid_(0x[0-9A-Fa-f]+_0x[0-9A-Fa-f]+)') { $matches[1] } else { 'x' } } | ForEach-Object {
        $s = ($_.Group | Measure-Object UtilizationPercentage -Sum).Sum; if ($s -gt $best) { $best = $s } }
      if ($best -gt 100) { $best = 100 }
      $o.Add("gpu.load=$best")
    }
    $mem = Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUAdapterMemory
    if ($mem) {
      $u = ($mem | Measure-Object DedicatedUsage -Maximum).Maximum
      if ($u) { $o.Add('gpu.vramused=' + [int]($u / 1MB)) }
    }
    if ($gpuI.AdapterRAM -gt 0 -and $gpuI.AdapterRAM -lt 4294967295) { $o.Add('gpu.vramtotal=' + [int]($gpuI.AdapterRAM / 1MB)) }
  }

  # ---- Temperatures (slow sources refreshed every few loops) ----
  if ($loop % 3 -eq 0) {
    $zt = @(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature | ForEach-Object { [math]::Round($_.CurrentTemperature / 10 - 273.15, 1) } | Where-Object { $_ -gt 0 -and $_ -lt 120 })
    if ($zt.Count) { $acpi = [string]($zt | Measure-Object -Maximum).Maximum } else { $acpi = '' }
  }
  if ($acpi) { $o.Add("cpu.temp=$acpi"); $o.Add('cpu.tsrc=ACPI') }
  if ($loop % 10 -eq 0) {
    $parts = @()
    foreach ($p in (Get-PhysicalDisk)) {
      $t = ($p | Get-StorageReliabilityCounter).Temperature
      if ($t -gt 0) { $parts += ((N $p.FriendlyName) + ':' + $t) }
    }
    $diskT = $parts -join ';'
  }
  if ($diskT) { $o.Add("disk.temps=$diskT") }

  # LibreHardwareMonitor / OpenHardwareMonitor (only if the user runs one) gives exact CPU/GPU temps
  foreach ($ns in 'root/LibreHardwareMonitor', 'root/OpenHardwareMonitor') {
    $sn = @(Get-CimInstance -Namespace $ns -ClassName Sensor | Where-Object { $_.SensorType -eq 'Temperature' })
    if ($sn.Count) {
      $c = $sn | Where-Object { $_.Identifier -match 'cpu' -and $_.Name -match 'Package|Tctl|Tdie|Average|CPU' } | Select-Object -First 1
      if (-not $c) { $c = $sn | Where-Object { $_.Identifier -match 'cpu' } | Select-Object -First 1 }
      if ($c) { $o.Add('cpu.temp=' + [math]::Round($c.Value, 1)); $o.Add("cpu.tsrc=$ns") }
      $g = $sn | Where-Object { $_.Identifier -match 'gpu' -and $_.Name -match 'Core' } | Select-Object -First 1
      if ($g) { $o.Add('gpu.temp=' + [math]::Round($g.Value, 1)) }
      break
    }
  }

  try { [IO.File]::WriteAllText($tmpf, ($o -join "`n")); Move-Item -Force $tmpf $Out } catch {}
  $loop++
  Start-Sleep -Milliseconds 700
}
