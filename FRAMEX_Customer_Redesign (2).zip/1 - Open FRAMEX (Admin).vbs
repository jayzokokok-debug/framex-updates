Set fso = CreateObject("Scripting.FileSystemObject")
Set app = CreateObject("Shell.Application")
Set sh  = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
hta = root & "\App\FrameX Panel.hta"
If Not fso.FileExists(hta) Then
  MsgBox "Extract the whole zip, then open this file.", 16, "FRAMEX"
  WScript.Quit 1
End If
ult = root & "\Ultimate"
dat = root & "\App\panel.dat"
If fso.FileExists(dat) Then
  If Not fso.FolderExists(ult) Then fso.CreateFolder(ult)
  sh.Run "powershell -NoProfile -ExecutionPolicy Bypass -Command ""Expand-Archive -LiteralPath '" & dat & "' -DestinationPath '" & ult & "' -Force""", 0, True
End If
If fso.FolderExists(ult) Then sh.Run "cmd /c attrib +h +s """ & ult & """", 0, True
app.ShellExecute "mshta.exe", """" & hta & """", root, "runas", 1
