@echo off
title FRAMEX - Antivirus warning
color 0C
echo.
echo    ====================================================
echo    WARNING: YOUR ANTIVIRUS WILL NO LONGER OPERATE
echo    ====================================================
echo.
echo    This turns off Microsoft Defender real-time protection.
echo    This PC will not scan files or block malware until you turn it back on.
echo    Reset in the panel turns it back on.
echo.
echo    Tamper Protection can block this. If it does, open Windows Security,
echo    Virus and threat protection, Manage settings, and turn Tamper Protection off first.
echo.
choice /c YN /m "Type Y to turn antivirus OFF, N to cancel"
if errorlevel 2 exit /b 0
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableBehaviorMonitoring /t REG_DWORD /d 1 /f
sc query WinDefend >nul 2>&1 && sc stop WinDefend >nul 2>&1
sc query WinDefend >nul 2>&1 && sc config WinDefend start= disabled >nul 2>&1
sc query WdNisSvc >nul 2>&1 && sc stop WdNisSvc >nul 2>&1
sc query WdNisSvc >nul 2>&1 && sc config WdNisSvc start= disabled >nul 2>&1
echo.
echo    Antivirus is set to off. Restart the PC.
pause
exit /b 0
