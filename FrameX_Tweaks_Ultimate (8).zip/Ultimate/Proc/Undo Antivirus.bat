@echo off
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableBehaviorMonitoring /f >nul 2>&1
sc query WinDefend >nul 2>&1 && sc config WinDefend start= auto >nul 2>&1
sc query WdNisSvc >nul 2>&1 && sc config WdNisSvc start= demand >nul 2>&1
exit /b 0
