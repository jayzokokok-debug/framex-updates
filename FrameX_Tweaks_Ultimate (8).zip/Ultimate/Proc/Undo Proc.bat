@echo off
sc query SysMain >nul 2>&1 && sc config SysMain start= demand >nul 2>&1
sc query WSearch >nul 2>&1 && sc config WSearch start= demand >nul 2>&1
sc query DoSvc >nul 2>&1 && sc config DoSvc start= demand >nul 2>&1
sc query DusmSvc >nul 2>&1 && sc config DusmSvc start= demand >nul 2>&1
sc query TrkWks >nul 2>&1 && sc config TrkWks start= demand >nul 2>&1
sc query AJRouter >nul 2>&1 && sc config AJRouter start= demand >nul 2>&1
sc query ALG >nul 2>&1 && sc config ALG start= demand >nul 2>&1
sc query edgeupdate >nul 2>&1 && sc config edgeupdate start= demand >nul 2>&1
sc query edgeupdatem >nul 2>&1 && sc config edgeupdatem start= demand >nul 2>&1
sc query SSDPSRV >nul 2>&1 && sc config SSDPSRV start= demand >nul 2>&1
sc query upnphost >nul 2>&1 && sc config upnphost start= demand >nul 2>&1
sc query WMPNetworkSvc >nul 2>&1 && sc config WMPNetworkSvc start= demand >nul 2>&1
sc query icssvc >nul 2>&1 && sc config icssvc start= demand >nul 2>&1
sc query RemoteAccess >nul 2>&1 && sc config RemoteAccess start= demand >nul 2>&1
sc query PrintNotify >nul 2>&1 && sc config PrintNotify start= demand >nul 2>&1
sc query TabletInputService >nul 2>&1 && sc config TabletInputService start= demand >nul 2>&1
sc query WpnService >nul 2>&1 && sc config WpnService start= demand >nul 2>&1
sc query CDPSvc >nul 2>&1 && sc config CDPSvc start= demand >nul 2>&1
sc query LanmanServer >nul 2>&1 && sc config LanmanServer start= demand >nul 2>&1
sc query FDResPub >nul 2>&1 && sc config FDResPub start= demand >nul 2>&1
sc query WalletService >nul 2>&1 && sc config WalletService start= demand >nul 2>&1
sc query SCardSvr >nul 2>&1 && sc config SCardSvr start= demand >nul 2>&1
sc query WbioSrvc >nul 2>&1 && sc config WbioSrvc start= demand >nul 2>&1
sc query FrameServer >nul 2>&1 && sc config FrameServer start= demand >nul 2>&1
sc query stisvc >nul 2>&1 && sc config stisvc start= demand >nul 2>&1
sc query WpcMonSvc >nul 2>&1 && sc config WpcMonSvc start= demand >nul 2>&1
sc query SEMgrSvc >nul 2>&1 && sc config SEMgrSvc start= demand >nul 2>&1
sc query vmickvpexchange >nul 2>&1 && sc config vmickvpexchange start= demand >nul 2>&1
reg delete HKLM\SOFTWARE\Policies\Microsoft\Dsh /v AllowNewsAndInterests /f >nul 2>&1
exit /b 0
