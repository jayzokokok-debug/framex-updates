@echo off
set "HERE=%~dp0"
if exist "%HERE%Services\Revert.bat" call "%HERE%Services\Revert.bat"
if exist "%HERE%Regedit\Revert Defaults.reg" reg import "%HERE%Regedit\Revert Defaults.reg" >nul 2>&1
if exist "%HERE%Clipzz\Revert Clipzz.reg" reg import "%HERE%Clipzz\Revert Clipzz.reg" >nul 2>&1
sc query DiagTrack >nul 2>&1 && sc config DiagTrack start= auto >nul 2>&1
powercfg -h on >nul 2>&1
powercfg -restoredefaultschemes >nul 2>&1
powercfg -setactive SCHEME_BALANCED >nul 2>&1
reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d 1 /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold1 /t REG_SZ /d 6 /f >nul
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold2 /t REG_SZ /d 10 /f >nul
reg add "HKCU\Control Panel\Keyboard" /v KeyboardDelay /t REG_SZ /d 1 /f >nul
reg add "HKCU\Control Panel\Keyboard" /v KeyboardSpeed /t REG_SZ /d 31 /f >nul
if exist "%HERE%More\Revert More.reg" reg import "%HERE%More\Revert More.reg" >nul 2>&1
if exist "%HERE%Cpu\Undo Cpu.bat" call "%HERE%Cpu\Undo Cpu.bat"
if exist "%HERE%Cpu\Undo Process Cut.bat" call "%HERE%Cpu\Undo Process Cut.bat"
if exist "%HERE%Fps\Undo Fps.bat" call "%HERE%Fps\Undo Fps.bat"
if exist "%HERE%Proc\Undo Proc.bat" call "%HERE%Proc\Undo Proc.bat"
if exist "%HERE%Proc\Undo Antivirus.bat" call "%HERE%Proc\Undo Antivirus.bat"
exit /b 0
