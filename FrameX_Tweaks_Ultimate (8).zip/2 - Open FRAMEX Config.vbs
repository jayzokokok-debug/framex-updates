Set fso = CreateObject("Scripting.FileSystemObject")
Set app = CreateObject("Shell.Application")
root = fso.GetParentFolderName(WScript.ScriptFullName)
hta = root & "\App\FrameX Panel Config.hta"
If Not fso.FileExists(hta) Then
  MsgBox "Could not find FrameX Panel Config.hta", 16, "FRAMEX"
  WScript.Quit 1
End If
app.ShellExecute "mshta.exe", """" & hta & """", root, "runas", 1
