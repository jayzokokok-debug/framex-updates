@echo off
title FRAMEX - Restore Task Manager and Services
net session >nul 2>&1
if not %errorlevel%==0 (
  echo Requesting administrator...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo.
echo    Clearing Task Manager locks...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /f >nul 2>&1
reg delete "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v DisableTaskMgr /t REG_DWORD /d 0 /f >nul
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\taskmgr.exe" /v Debugger /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\mmc.exe" /v Debugger /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\DisallowRun" /v taskmgr.exe /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\DisallowRun" /v taskmgr.exe /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\DisallowRun" /v mmc.exe /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\DisallowRun" /v mmc.exe /f >nul 2>&1
reg delete "HKCU\Software\Policies\Microsoft\MMC\{58221C67-EA27-11CF-ADCF-00AA00A80033}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Policies\Microsoft\MMC\{58221C67-EA27-11CF-ADCF-00AA00A80033}" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoControlPanel /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoControlPanel /f >nul 2>&1
echo    Turning Services components back on...
for %%S in (AppInfo gpsvc Schedule Winmgmt EventLog DPS SamSs TrustedInstaller) do (
  sc config %%S start= demand >nul 2>&1
  sc start %%S >nul 2>&1
)
sc config gpsvc start= auto >nul 2>&1
sc config Schedule start= auto >nul 2>&1
sc config Winmgmt start= auto >nul 2>&1
sc config EventLog start= auto >nul 2>&1
sc config DPS start= auto >nul 2>&1
gpupdate /force >nul 2>&1
echo.
echo    Done. Opening Task Manager and Services.
start "" "%SystemRoot%\System32\Taskmgr.exe"
start "" "%SystemRoot%\System32\mmc.exe" "%SystemRoot%\System32\services.msc"
echo.
echo    If a window did not open, restart the PC and run this file again.
pause
exit /b 0
