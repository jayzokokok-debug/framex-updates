param([Parameter(Mandatory=$true)][string]$Zip, [Parameter(Mandatory=$true)][string]$Dest)
# FRAMEX unpacker. Extracts a zip of ANY extension (Expand-Archive rejects ".dat"), overwriting existing files.
$ErrorActionPreference = 'Stop'
$log = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'unpack.log'
try {
  Add-Type -AssemblyName System.IO.Compression
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  if (-not (Test-Path -LiteralPath $Zip)) { throw "Package not found: $Zip" }
  if (-not (Test-Path -LiteralPath $Dest)) { New-Item -ItemType Directory -Path $Dest -Force | Out-Null }
  $root = [IO.Path]::GetFullPath($Dest).TrimEnd('\') + '\'
  $z = [IO.Compression.ZipFile]::OpenRead($Zip)
  try {
    foreach ($e in $z.Entries) {
      $rel = $e.FullName -replace '/', '\'
      $target = [IO.Path]::GetFullPath((Join-Path $root $rel))
      if (-not $target.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { continue }  # block path traversal
      if ($e.FullName.EndsWith('/') -or $e.Name -eq '') {
        if (-not (Test-Path -LiteralPath $target)) { New-Item -ItemType Directory -Path $target -Force | Out-Null }
        continue
      }
      $dir = Split-Path -Parent $target
      if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
      if (Test-Path -LiteralPath $target) { Set-ItemProperty -LiteralPath $target -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue }
      [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
    }
  } finally { $z.Dispose() }
  if (Test-Path -LiteralPath $log) { Remove-Item -LiteralPath $log -Force -ErrorAction SilentlyContinue }
  exit 0
} catch {
  try { ("{0}  {1}" -f (Get-Date), $_.Exception.Message) | Set-Content -LiteralPath $log -Encoding ASCII } catch {}
  exit 1
}
