@echo off
title FRAMEX TWEAKS - Untweak All
color 0D
echo.
echo    ========================================
echo              FRAMEX TWEAKS
echo           UNTWEAK ALL
echo    ========================================
echo.
call "%~dp0Undo All Silent.bat"
echo    Done. Restart the PC so every change finishes.
if /I "%~1"=="SILENT" exit /b 0
echo    Press any key to close...
pause >nul
exit /b 0
