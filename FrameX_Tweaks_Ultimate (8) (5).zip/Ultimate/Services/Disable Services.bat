@echo off
title FRAMEX TWEAKS - Services
color 0D
echo.
echo    Disabling optional services only.
echo    Admin, Task Manager, Services, Bluetooth, printing, and search stay available.
echo.
sc query AJRouter >nul 2>&1 && sc config AJRouter start= disabled >nul
sc query ALG >nul 2>&1 && sc config ALG start= disabled >nul
sc query DiagTrack >nul 2>&1 && sc config DiagTrack start= disabled >nul
sc query dmwappushservice >nul 2>&1 && sc config dmwappushservice start= disabled >nul
sc query MapsBroker >nul 2>&1 && sc config MapsBroker start= disabled >nul
sc query RemoteRegistry >nul 2>&1 && sc config RemoteRegistry start= disabled >nul
sc query RetailDemo >nul 2>&1 && sc config RetailDemo start= disabled >nul
sc query WerSvc >nul 2>&1 && sc config WerSvc start= disabled >nul
sc query Fax >nul 2>&1 && sc config Fax start= disabled >nul
sc query wisvc >nul 2>&1 && sc config wisvc start= disabled >nul
sc query XboxGipSvc >nul 2>&1 && sc config XboxGipSvc start= disabled >nul
sc query XblAuthManager >nul 2>&1 && sc config XblAuthManager start= disabled >nul
sc query XblGameSave >nul 2>&1 && sc config XblGameSave start= disabled >nul
sc query XboxNetApiSvc >nul 2>&1 && sc config XboxNetApiSvc start= disabled >nul
echo.
echo    Done.
echo    Press any key to close...
pause >nul
exit /b 0
