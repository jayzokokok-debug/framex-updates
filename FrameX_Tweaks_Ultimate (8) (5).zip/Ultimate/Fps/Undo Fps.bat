@echo off
if exist "%~dp0Revert Fps.reg" reg import "%~dp0Revert Fps.reg" >nul 2>&1
powercfg -setactive SCHEME_BALANCED >nul 2>&1
exit /b 0
