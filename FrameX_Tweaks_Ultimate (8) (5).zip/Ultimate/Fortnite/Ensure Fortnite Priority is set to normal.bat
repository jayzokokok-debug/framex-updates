@echo off
title FRAMEX TWEAKS - Fortnite Priority
color 0D
echo.
echo    ========================================
echo              FRAMEX TWEAKS
echo    ========================================
echo.
echo    Setting Fortnite CPU priority to Normal...
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\FortniteClient-Win64-Shipping.exe\PerfOptions" /v "CpuPriorityClass" /t REG_DWORD /d "2" /f >nul
echo.
echo    Done.
echo    Press any key to close...
pause >nul
exit /b 0
