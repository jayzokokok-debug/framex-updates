:: Made by Quaked
:: TikTok: _Quaked_
:: Discord: https://discord.gg/8NqDSMzYun

@echo off
title Fortnite Optimizer V2.1
color 9

:: Check for Admin Privileges.
fltmc >nul 2>&1
if not %errorlevel% == 0 (
    Powershell -NoProfile -Command "Write-Host 'Fortnite Optimizer is required to be run as *Administrator.*' -ForegroundColor White -BackgroundColor Red" 
    Powershell -NoProfile -Command "Write-Host 'Please click *Yes* to the following prompt!' -ForegroundColor White -BackgroundColor Red" 
    timeout 3 > nul
    Powershell -NoProfile Start -Verb RunAs '%0'
    exit /b 0
)

:: Configuring ANSI Colors. 
set "Reset=[0m"
set "DarkYellow=[33m"
set "Red=[91m"
set "Green=[92m"
set "Blue=[94m"
set "Cyan=[96m"
set "White=[97m"

:: Check if Fortnite exist in the Default Path.
if not exist "C:\Program Files\Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe" (
   goto :Default_Path_Not_Found 
) else (
   set "FortnitePath=C:\Program Files\Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe"
   goto :Download_Tools
)

:: Default Fortnite Path not found.
:Default_Path_Not_Found
cls
color C
chcp 65001 >nul 2>&1
echo ╔═══════════════════════════════════════════════════╗
echo ║ ⚠️ Fortnite is not installed in the default Path. ║
echo ╚═══════════════════════════════════════════════════╝
echo • Fortnite is likely installed on another drive or location!
echo.
echo %White%[Choose an option]
echo %Green%1. Manually Input Path - *Tries to download the tools folder again*
echo %DarkYellow%2. Continue Anyway - *Allows the user to continue with Fortnite Optimizer regardless*
echo %Cyan%3. Learn More - *Explains the error*
echo %Red%4. Exit - *Closes Fortnite Optimizer*
set /p option="%White%Enter option number: "
chcp 65001 >nul 2>&1
if "%option%"=="1" (
    goto :Manual_Path
) else if "%option%"=="2" (
    cls
    color C
    echo ╔════════════════════════════════════════╗
    echo ║ ⚠️ Continuing with Fortnite Optimizer. ║
    echo ╚════════════════════════════════════════╝
    echo • Now continuing in 2 seconds!
    timeout 2 > nul
    cls
    chcp 437 >nul
    goto :Download_Tools
) else if "%option%"=="3" (
    cls
    color A
    echo ╔═════════════════════════╗
    echo ║ ✅ Opening Github Page. ║
    echo ╚═════════════════════════╝
    echo • Launching the Github page in 2 seconds!
    timeout 2 > nul
    start "" "https://github.com/QuakedK/Fortnite-Optimizer/blob/main/Help/Fortnite%%20Path.md"
    echo.
    <nul set /p="→ Press any key to continue . . . "
    pause >nul
    goto :Default_Path_Not_Found
) else if "%option%"=="4" (
    cls
    color A
    echo ╔════════════════════════════════╗
    echo ║ ✅ Exiting Fortnite Optimizer. ║
    echo ╚════════════════════════════════╝
    echo • Now closing Fortnite Optimizer in 5 seconds!
    timeout 5 > nul
    exit
) else (
    cls
    chcp 437 >nul
    Powershell -NoProfile -Command "Write-Host 'Invalid choice, Please choose options 1-2.' -ForegroundColor White -BackgroundColor Red"
    timeout 2 > nul
    goto :Tools_Download_Failed
)

:: Add Manual Fortnite Path.
:Manual_Path
cls
color A
chcp 65001 >nul 2>&1
echo ╔═══════════════════════════════════════════════════════════════════════════════════════╗
echo ║ ✅ Adding Manual Fortnite Path. [Path must include FortniteClient-Win64-Shipping.exe] ║
echo ╚═══════════════════════════════════════════════════════════════════════════════════════╝
echo • Example Path: "C:\Program Files\Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe"
echo.
set /p FortnitePath="→ Enter Your Fortnite Path: "
set "FortnitePath=%FortnitePath:"=%"
echo.
echo → Your Entered Path: "%FortnitePath%"
echo.
<nul set /p="→ Press any key to continue . . . "
pause >nul
cls
chcp 437 >nul
goto :Download_Tools

:: Downloading Fortnite Optimizer Tools at start.
:Download_Tools
set "FileURL=https://github.com/QuakedK/Fortnite-Optimizer/raw/refs/heads/main/Downloads/FortniteOptimizerTools.zip"
set "FileName=Fortnite Optimizer Tools.zip"
set "ExtractFolder=C:\Fortnite Optimizer Tools"
set "DownloadsFolder=C:\"
curl -s -L "%FileURL%" -o "%DownloadsFolder%\%FileName%"
if exist "%DownloadsFolder%\%FileName%" (  
   mkdir "%ExtractFolder%" >nul 2>&1
   pushd "%ExtractFolder%" >nul 2>&1
   tar -xf "%DownloadsFolder%\%FileName%" --strip-components=1 >nul 2>&1
   popd >nul 2>&1
   del /q "C:\Fortnite Optimizer Tools.zip" >nul 2>&1
   goto :Fortnite_Optimizer_Start_Screen
) else (
   goto :Tools_Download_Failed
)

::  Fortnite Optimizer Tools failed to download.
:Tools_Download_Failed
cls
color C
chcp 65001 >nul 2>&1
echo ╔════════════════════════════════════════════════════════╗
echo ║ ⚠️ Fortnite Optimizer Tools Folder failed to download. ║
echo ╚════════════════════════════════════════════════════════╝
echo • Please ensure you're connected to the internet!
echo.
echo %White%[Choose an option]
echo %Green%1. Retry - *Tries to download the tools folder again*
echo %Red%2. Exit - *Closes Fortnite Optimizer*
set /p option="%White%Enter option number: "
chcp 65001 >nul 2>&1
if "%option%"=="1" (
    cls
    color A
    echo ╔════════════════════════════════════════════════╗
    echo ║ ✅ Retrying Fortnite Optimizer Tools download. ║
    echo ╚════════════════════════════════════════════════╝
    echo • Attempting download again in 2 seconds!
    timeout 2 > nul
    cls
    chcp 437 >nul
    goto :Download_Tools
) else if "%option%"=="2" (
    cls
    color A
    echo ╔════════════════════════════════╗
    echo ║ ✅ Exiting Fortnite Optimizer. ║
    echo ╚════════════════════════════════╝
    echo • Now closing Fortnite Optimizer in 5 seconds!
    timeout 5 > nul
    exit
) else (
    cls
    chcp 437 >nul
    Powershell -NoProfile -Command "Write-Host 'Invalid choice, Please choose options 1-2.' -ForegroundColor White -BackgroundColor Red"
    timeout 2 > nul
    goto :Tools_Download_Failed
)

:: Fortnite Optimizer Start Screen.
:Fortnite_Optimizer_Start_Screen
cls
color 9
chcp 65001 >nul 2>&1
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.                             ███████╗ ██████╗ ██████╗ ████████╗███╗   ██╗██╗████████╗███████╗       
echo.                             ██╔════╝██╔═══██╗██╔══██╗╚══██╔══╝████╗  ██║██║╚══██╔══╝██╔════╝       
echo.                             █████╗  ██║   ██║██████╔╝   ██║   ██╔██╗ ██║██║   ██║   █████╗         
echo.                             ██╔══╝  ██║   ██║██╔══██╗   ██║   ██║╚██╗██║██║   ██║   ██╔══╝         
echo.                             ██║     ╚██████╔╝██║  ██║   ██║   ██║ ╚████║██║   ██║   ███████╗       
echo.                             ╚═╝      ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═══╝╚═╝   ╚═╝   ╚══════╝       
echo.                                                                       
echo.                             ██████╗ ██████╗ ████████╗██╗███╗   ███╗██╗███████╗███████╗██████╗     
echo.                            ██╔═══██╗██╔══██╗╚══██╔══╝██║████╗ ████║██║╚══███╔╝██╔════╝██╔══██╗    
echo.                            ██║   ██║██████╔╝   ██║   ██║██╔████╔██║██║  ███╔╝ █████╗  ██████╔╝    
echo.                            ██║   ██║██╔═══╝    ██║   ██║██║╚██╔╝██║██║ ███╔╝  ██╔══╝  ██╔══██╗    
echo.                            ╚██████╔╝██║        ██║   ██║██║ ╚═╝ ██║██║███████╗███████╗██║  ██║    
echo.                             ╚═════╝ ╚═╝        ╚═╝   ╚═╝╚═╝     ╚═╝╚═╝╚══════╝╚══════╝╚═╝  ╚═╝    
echo. 
echo.                                  ╔════════════════════════════════════════════════════╗
echo.                                  ║              Version 2.1 - By Quaked               ║
echo.                                  ╚════════════════════════════════════════════════════╝
echo.
echo.
echo.
echo. ╔═════════╗                                                                        
echo. ║ Loading ║                                              
echo. ╚═════════╝
timeout 2 > nul 

:: Graphics Preferences, Priority and FSO.
cls
color 9
chcp 65001 >nul 2>&1
echo ╔═════════════════════════════════════════════════════════╗
echo ║ ✅ Auto Setting Graphics Preferences, Priority and FSO. ║
echo ╚═════════════════════════════════════════════════════════╝
echo • Setting Fortnite Graphics Preference to High Performance.
reg add "HKCU\SOFTWARE\Microsoft\DirectX\UserGpuPreferences" /v "%FortnitePath%" /t REG_SZ /d "GpuPreference=2" /f >nul 2>&1

echo • Setting Fortnite to High Priority.
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\FortniteClient-Win64-Shipping.exe\PerfOptions" /v "CpuPriorityClass" /t REG_DWORD /d "3" /f >nul 2>&1

echo • Disabling Fortnite's FSO.
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "%FortnitePath%" /t REG_SZ /d "~ DISABLEDXMAXIMIZEDWINDOWEDMODE HIGHDPIAWARE" /f >nul 2>&1

echo ✔  Graphics Preferences, Priority and FSO applied successfully.
timeout 3 > nul 


:: Import Fortnite Game Config.
:Import_Config
cls
color 9
chcp 65001 >nul 2>&1
echo ╔═══════════════════════════════════════════════╗
echo ║ ✅ Importing Optimized Fortnite Game Configs. ║
echo ╚═══════════════════════════════════════════════╝
echo • Please choose a config depending on your use case.
echo.
echo %White%[Choose an option]
echo %Green%1. Legacy Performance Mode.
echo %Blue%2. New Performance Mode.
echo %Blue%3. DX 12.
echo %Blue%4. DX 11.
echo %Red%5. Skip.   
set /p option="%White%Enter option number: "
if "%option%"=="1" (
    cls
    color A
    echo ╔═══════════════════════════════════════╗
    echo ║ ✅ Importing Legacy Performance Mode. ║
    echo ╚═══════════════════════════════════════╝
    move /Y "C:\Fortnite Optimizer Tools\Legacy Performance Mode\GameUserSettings.ini" "%USERPROFILE%\AppData\Local\FortniteGame\Saved\Config\WindowsClient" >nul 2>&1
    if errorlevel 1 (
        echo %Red%❌ Failed to import Legacy Performance Mode!
        timeout 3 > nul
        goto :Import_Failed.
    ) else (
        echo %Green%✔  Successfully imported Legacy Performance Mode!
        timeout 3 > nul
        goto :Command_Line
    )
) else if "%option%"=="2" (
    cls
    color A
    echo ╔════════════════════════════════════╗
    echo ║ ✅ Importing New Performance Mode. ║
    echo ╚════════════════════════════════════╝
    move /Y "C:\Fortnite Optimizer Tools\New Performance Mode\GameUserSettings.ini" "%USERPROFILE%\AppData\Local\FortniteGame\Saved\Config\WindowsClient" >nul 2>&1
    if errorlevel 1 (
        echo %Red%❌ Failed to import New Performance Mode!
        timeout 3 > nul
        goto :Import_Failed.
    ) else (
        echo %Green%✔  Successfully imported New Legacy Performance Mode!
        timeout 3 > nul
        goto :Command_Line
    )
) else if "%option%"=="3" (
    cls
    color A
    echo ╔═════════════════════╗
    echo ║ ✅ Importing DX 12. ║
    echo ╚═════════════════════╝
    move /Y "C:\Fortnite Optimizer Tools\DX 12\GameUserSettings.ini" "%USERPROFILE%\AppData\Local\FortniteGame\Saved\Config\WindowsClient" >nul 2>&1
    if errorlevel 1 (
        echo %Red%❌ Failed to import DX 12!
        timeout 3 > nul
        goto :Import_Failed.
    ) else (
        echo %Green%✔  Successfully imported DX 12!
        timeout 3 > nul
        goto :Command_Line
    )
) else if "%option%"=="4" (
    cls
    color A
    echo ╔═════════════════════╗
    echo ║ ✅ Importing DX 11. ║
    echo ╚═════════════════════╝
    move /Y "C:\Fortnite Optimizer Tools\DX 11\GameUserSettings.ini" "%USERPROFILE%\AppData\Local\FortniteGame\Saved\Config\WindowsClient" >nul 2>&1
    if errorlevel 1 (
        echo %Red%❌ Failed to import DX 11!
        timeout 3 > nul
        goto :Import_Failed.
    ) else (
        echo %Green%✔  Successfully imported DX 11!
        timeout 3 > nul
        goto :Command_Line
    )
) else if "%option%"=="5" (
    echo ✔  Skipping!
    timeout 2 > nul
    goto :Command_Line
) else (
    cls
    chcp 437 >nul
    Powershell -NoProfile -Command "Write-Host 'Invalid choice, Please choose options 1-5.' -ForegroundColor White -BackgroundColor Red"
    timeout 2 > nul
    goto :Import_Config
)

:: Optimized Fortnite Game Config Import Failed.
:Import_Failed.
cls
color C
chcp 65001 >nul 2>&1
echo ╔═════════════════════════════════════════════════════╗
echo ║ ⚠️ Optimized Fortnite Game Config Failed to Import. ║
echo ╚═════════════════════════════════════════════════════╝
echo • Fortnite Optimizer Tools may be empty!
echo.
echo %White%[Choose an option]
echo %Green%1. Retry Import - *Tries to import the config again*
echo %DarkYellow%2. Continue Anyway - *Allows the user to continue with Fortnite Optimizer regardless*
echo %Red%3. Exit - *Closes Fortnite Optimizer*
set /p option="%White%Enter option number: "
chcp 65001 >nul 2>&1
if "%option%"=="1" (
    cls
    color A
    echo ╔══════════════════════════════════════════╗
    echo ║ ✅ Retrying Fortnite Game Config import. ║
    echo ╚══════════════════════════════════════════╝
    echo • Attempting import again in 2 seconds!
    timeout 2 > nul
    goto :Import_Config
) else if "%option%"=="2" (
    cls
    color C
    echo ╔════════════════════════════════════════╗
    echo ║ ⚠️ Continuing with Fortnite Optimizer. ║
    echo ╚════════════════════════════════════════╝
    echo • Now continuing in 2 seconds!
    timeout 2 > nul
    goto :Command_Line
) else if "%option%"=="3" (
    cls
    color A
    echo ╔════════════════════════════════╗
    echo ║ ✅ Exiting Fortnite Optimizer. ║
    echo ╚════════════════════════════════╝
    echo • Now closing Fortnite Optimizer in 5 seconds!
    rd /s /q "C:\Fortnite Optimizer Tools"
    timeout 5 > nul
    exit
) else (
    cls
    chcp 437 >nul
    Powershell -NoProfile -Command "Write-Host 'Invalid choice, Please choose options 1-3.' -ForegroundColor White -BackgroundColor Red"
    timeout 2 > nul
    goto :Import_Failed.
)

:: Fortnite Additional Command Line Arguments.
:Command_Line
cls
color 9
echo ╔═══════════════════════════════════════════════════════╗
echo ║ ✅ Adding Fortnite Additional Command Line Arguments. ║
echo ╚═══════════════════════════════════════════════════════╝
echo → Opening Epic Games Launcher in 2 seconds!
timeout 2 > nul
start "" "C:\Program Files\Epic Games\Launcher\Portal\Binaries\Win64\EpicGamesLauncher.exe"
echo.
echo → Launching the Github page in 3 seconds!
timeout 3 > nul
start "" "https://github.com/QuakedK/Fortnite-Optimizer/blob/main/Help/Additional%%20Command%%20Line%%20Arguments.md"
echo.
<nul set /p="→ Press any key to continue . . . "
pause >nul
goto :Done

:: Fortnite Optimizer Done Screen.
:Done
cls
color B
chcp 65001 >nul 2>&1
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                ██████╗ ███████╗███████╗████████╗ █████╗ ██████╗ ████████╗
echo.                                ██╔══██╗██╔════╝██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚══██╔══╝
echo.                                ██████╔╝█████╗  ███████╗   ██║   ███████║██████╔╝   ██║   
echo.                                ██╔══██╗██╔══╝  ╚════██║   ██║   ██╔══██║██╔══██╗   ██║   
echo.                                ██║  ██║███████╗███████║   ██║   ██║  ██║██║  ██║   ██║   
echo.                                ╚═╝  ╚═╝╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   
echo.
echo.                         ╔═════════════════════════════════════════════════════════════════════╗ 
echo.                         ║                                                                     ║ 
echo.                         ║             [1] Restart                 [2] Exit                    ║
echo.                         ║                                                                     ║
echo.                         ╚═════════════════════════════════════════════════════════════════════╝
echo.  
echo.
echo.
echo ____________________
set /p option="Enter option number: "
echo.
if "%option%"=="1" (
    cls
    color A
    echo ╔════════════════════════╗
    echo ║ ✅ Restarting your PC. ║
    echo ╚════════════════════════╝
    echo • Restarting your PC, in 5 seconds!
    rd /s /q "C:\Fortnite Optimizer Tools"
    timeout 5 > nul
    shutdown /r /t 0 
) else if "%option%"=="2" (
    cls
    color A
    echo ╔════════════════════════════════╗
    echo ║ ✅ Exiting Fortnite Optimizer. ║
    echo ╚════════════════════════════════╝
    echo %Red%• We recommend restarting your pc to apply the registry changes!
    rd /s /q "C:\Fortnite Optimizer Tools"
    timeout 3 > nul
    exit
) else (
    cls
    chcp 437 >nul
    Powershell -NoProfile -Command "Write-Host 'Invalid choice, Please choose 1 or 2.' -ForegroundColor White -BackgroundColor Red"
    timeout 2 > nul
    goto :Done
)