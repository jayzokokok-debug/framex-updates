:: Made by Quaked
:: TikTok: _Quaked_
:: Discord: https://discord.gg/8NqDSMzYun

:: Open Powershell without admin and install Spictify.
runas /machine:amd64 /trustlevel:0x20000 "Powershell -NoProfile -Command \"iwr -useb https://raw.githubusercontent.com/spicetify/cli/main/install.ps1 ^| iex\""
exit