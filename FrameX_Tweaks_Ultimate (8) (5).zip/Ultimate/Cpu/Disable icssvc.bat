@echo off
sc query icssvc >nul 2>&1 && sc stop icssvc >nul 2>&1
sc query icssvc >nul 2>&1 && sc config icssvc start= disabled >nul 2>&1
exit /b 0
