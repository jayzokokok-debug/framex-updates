@echo off
sc query SCardSvr >nul 2>&1 && sc stop SCardSvr >nul 2>&1
sc query SCardSvr >nul 2>&1 && sc config SCardSvr start= disabled >nul 2>&1
exit /b 0
