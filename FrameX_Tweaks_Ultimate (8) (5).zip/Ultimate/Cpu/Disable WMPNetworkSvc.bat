@echo off
sc query WMPNetworkSvc >nul 2>&1 && sc stop WMPNetworkSvc >nul 2>&1
sc query WMPNetworkSvc >nul 2>&1 && sc config WMPNetworkSvc start= disabled >nul 2>&1
exit /b 0
