@echo off
sc query SSDPSRV >nul 2>&1 && sc stop SSDPSRV >nul 2>&1
sc query SSDPSRV >nul 2>&1 && sc config SSDPSRV start= disabled >nul 2>&1
exit /b 0
