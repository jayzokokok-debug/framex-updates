@echo off
schtasks /Change /TN "\Microsoft\Windows\Maps\MapsUpdateTask" /DISABLE >nul 2>&1
exit /b 0
