@echo off
sc query dmwappushservice >nul 2>&1 && sc stop dmwappushservice >nul 2>&1
sc query dmwappushservice >nul 2>&1 && sc config dmwappushservice start= disabled >nul 2>&1
exit /b 0
