@echo off
sc query XboxGipSvc >nul 2>&1 && sc stop XboxGipSvc >nul 2>&1
sc query XboxGipSvc >nul 2>&1 && sc config XboxGipSvc start= disabled >nul 2>&1
exit /b 0
