@echo off
sc query WerSvc >nul 2>&1 && sc stop WerSvc >nul 2>&1
sc query WerSvc >nul 2>&1 && sc config WerSvc start= disabled >nul 2>&1
exit /b 0
