@echo off
sc query wisvc >nul 2>&1 && sc stop wisvc >nul 2>&1
sc query wisvc >nul 2>&1 && sc config wisvc start= disabled >nul 2>&1
exit /b 0
