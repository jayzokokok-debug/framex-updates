@echo off
sc query RetailDemo >nul 2>&1 && sc stop RetailDemo >nul 2>&1
sc query RetailDemo >nul 2>&1 && sc config RetailDemo start= disabled >nul 2>&1
exit /b 0
