@echo off
sc query MessagingService >nul 2>&1 && sc stop MessagingService >nul 2>&1
sc query MessagingService >nul 2>&1 && sc config MessagingService start= manual >nul 2>&1
exit /b 0
