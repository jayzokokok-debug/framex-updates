@echo off
sc query WpcMonSvc >nul 2>&1 && sc stop WpcMonSvc >nul 2>&1
sc query WpcMonSvc >nul 2>&1 && sc config WpcMonSvc start= disabled >nul 2>&1
exit /b 0
