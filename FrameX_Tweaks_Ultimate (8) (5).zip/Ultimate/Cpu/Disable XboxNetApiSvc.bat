@echo off
sc query XboxNetApiSvc >nul 2>&1 && sc stop XboxNetApiSvc >nul 2>&1
sc query XboxNetApiSvc >nul 2>&1 && sc config XboxNetApiSvc start= disabled >nul 2>&1
exit /b 0
