@echo off
sc query DiagTrack >nul 2>&1 && sc stop DiagTrack >nul 2>&1
sc query DiagTrack >nul 2>&1 && sc config DiagTrack start= disabled >nul 2>&1
exit /b 0
