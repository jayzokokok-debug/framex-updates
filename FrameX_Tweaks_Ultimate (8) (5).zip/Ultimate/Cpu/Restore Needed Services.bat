@echo off
echo Re-enabling services that Windows needs...
for %%S in (AppInfo gpsvc Schedule Winmgmt EventLog DPS SamSs TrustedInstaller CryptSvc Spooler SysMain WSearch TokenBroker DoSvc FrameServer stisvc WiaRpc WdiServiceHost WdiSystemHost) do (
  sc config %%S start= demand >nul 2>&1
)
sc config gpsvc start= auto >nul 2>&1
sc config Schedule start= auto >nul 2>&1
sc config Winmgmt start= auto >nul 2>&1
sc config EventLog start= auto >nul 2>&1
sc config CryptSvc start= auto >nul 2>&1
sc config Spooler start= auto >nul 2>&1
sc config SysMain start= auto >nul 2>&1
sc config WSearch start= auto >nul 2>&1
reg add HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System /v DisableTaskMgr /t REG_DWORD /d 0 /f >nul
reg add HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v DisableTaskMgr /t REG_DWORD /d 0 /f >nul
echo Done. Restart the PC.
pause
