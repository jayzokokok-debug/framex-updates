@echo off
sc query SysMain >nul 2>&1 && sc config SysMain start= demand >nul 2>&1
sc query WSearch >nul 2>&1 && sc config WSearch start= demand >nul 2>&1
sc query DiagTrack >nul 2>&1 && sc config DiagTrack start= demand >nul 2>&1
sc query dmwappushservice >nul 2>&1 && sc config dmwappushservice start= demand >nul 2>&1
sc query WerSvc >nul 2>&1 && sc config WerSvc start= demand >nul 2>&1
sc query MapsBroker >nul 2>&1 && sc config MapsBroker start= demand >nul 2>&1
sc query RetailDemo >nul 2>&1 && sc config RetailDemo start= demand >nul 2>&1
sc query XblAuthManager >nul 2>&1 && sc config XblAuthManager start= demand >nul 2>&1
sc query XblGameSave >nul 2>&1 && sc config XblGameSave start= demand >nul 2>&1
sc query XboxNetApiSvc >nul 2>&1 && sc config XboxNetApiSvc start= demand >nul 2>&1
sc query XboxGipSvc >nul 2>&1 && sc config XboxGipSvc start= demand >nul 2>&1
sc query wisvc >nul 2>&1 && sc config wisvc start= demand >nul 2>&1
sc query lfsvc >nul 2>&1 && sc config lfsvc start= demand >nul 2>&1
sc query SharedAccess >nul 2>&1 && sc config SharedAccess start= demand >nul 2>&1
sc query RemoteRegistry >nul 2>&1 && sc config RemoteRegistry start= demand >nul 2>&1
sc query Fax >nul 2>&1 && sc config Fax start= demand >nul 2>&1
sc query TabletInputService >nul 2>&1 && sc config TabletInputService start= demand >nul 2>&1
sc query WbioSrvc >nul 2>&1 && sc config WbioSrvc start= demand >nul 2>&1
sc query PhoneSvc >nul 2>&1 && sc config PhoneSvc start= demand >nul 2>&1
sc query MessagingService >nul 2>&1 && sc config MessagingService start= demand >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Application Experience\ProgramDataUpdater" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Maps\MapsUpdateTask" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Maps\MapsToastTask" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Feedback\Siuf\DmClient" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload" /ENABLE >nul 2>&1
schtasks /Change /TN "\Microsoft\Windows\Autochk\Proxy" /ENABLE >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BackgroundAppGlobalToggle /t REG_DWORD /d 1 /f >nul
exit /b 0
