@echo off
sc query PrintNotify >nul 2>&1 && sc stop PrintNotify >nul 2>&1
sc query PrintNotify >nul 2>&1 && sc config PrintNotify start= disabled >nul 2>&1
exit /b 0
