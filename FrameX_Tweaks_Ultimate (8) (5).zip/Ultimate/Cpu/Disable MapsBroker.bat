@echo off
sc query MapsBroker >nul 2>&1 && sc stop MapsBroker >nul 2>&1
sc query MapsBroker >nul 2>&1 && sc config MapsBroker start= disabled >nul 2>&1
exit /b 0
