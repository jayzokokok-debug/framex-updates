@echo off
title FRAMEX TWEAKS - Disable MPO
color 0D
echo.
echo    ========================================
echo              FRAMEX TWEAKS
echo    ========================================
echo.
echo    Disabling Multi-Plane Overlay (MPO)...
reg add "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode /t REG_DWORD /d 5 /f >nul
echo.
echo    Done.
echo    Press any key to close...
pause >nul
exit /b 0
