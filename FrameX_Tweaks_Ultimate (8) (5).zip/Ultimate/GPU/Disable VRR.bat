@echo off
title FRAMEX TWEAKS - Disable VRR
color 0D
echo.
echo    ========================================
echo              FRAMEX TWEAKS
echo    ========================================
echo.
echo    Disabling Variable Refresh Rate optimize...
reg add "HKCU\Software\Microsoft\DirectX\UserGpuPreferences" /v VRROptimizeEnable /t REG_DWORD /d 0 /f >nul
echo.
echo    Done.
echo    Press any key to close...
pause >nul
exit /b 0
