Add-Type @"
using System;
using System.Runtime.InteropServices;
public class FRAMEXMouse {
  [DllImport("user32.dll", SetLastError=true)]
  public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, int[] pvParam, uint fWinIni);
}
"@
$mouse = @(0, 0, 0)
[FRAMEXMouse]::SystemParametersInfo(0x0004, 0, $mouse, 0x03) | Out-Null
