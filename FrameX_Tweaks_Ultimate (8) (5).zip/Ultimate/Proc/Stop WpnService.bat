@echo off
sc query WpnService >nul 2>&1 && sc stop WpnService >nul 2>&1
sc query WpnService >nul 2>&1 && sc config WpnService start= disabled >nul 2>&1
exit /b 0
