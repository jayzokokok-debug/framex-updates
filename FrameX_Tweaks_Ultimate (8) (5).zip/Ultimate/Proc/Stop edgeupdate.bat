@echo off
sc query edgeupdate >nul 2>&1 && sc stop edgeupdate >nul 2>&1
sc query edgeupdate >nul 2>&1 && sc config edgeupdate start= disabled >nul 2>&1
exit /b 0
