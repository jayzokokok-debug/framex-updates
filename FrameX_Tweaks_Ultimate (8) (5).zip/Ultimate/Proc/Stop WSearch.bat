@echo off
sc query WSearch >nul 2>&1 && sc stop WSearch >nul 2>&1
sc query WSearch >nul 2>&1 && sc config WSearch start= disabled >nul 2>&1
exit /b 0
