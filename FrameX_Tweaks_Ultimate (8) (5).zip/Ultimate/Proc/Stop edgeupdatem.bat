@echo off
sc query edgeupdatem >nul 2>&1 && sc stop edgeupdatem >nul 2>&1
sc query edgeupdatem >nul 2>&1 && sc config edgeupdatem start= disabled >nul 2>&1
exit /b 0
