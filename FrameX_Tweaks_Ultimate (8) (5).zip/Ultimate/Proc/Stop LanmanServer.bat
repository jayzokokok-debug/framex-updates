@echo off
sc query LanmanServer >nul 2>&1 && sc stop LanmanServer >nul 2>&1
sc query LanmanServer >nul 2>&1 && sc config LanmanServer start= disabled >nul 2>&1
exit /b 0
