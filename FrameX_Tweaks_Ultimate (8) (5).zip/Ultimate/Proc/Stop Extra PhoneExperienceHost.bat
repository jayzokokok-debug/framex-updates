@echo off
sc query PhoneExperienceHost >nul 2>&1 && sc stop PhoneExperienceHost >nul 2>&1
sc query PhoneExperienceHost >nul 2>&1 && sc config PhoneExperienceHost start= disabled >nul 2>&1
exit /b 0
