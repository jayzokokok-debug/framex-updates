@echo off
sc query AJRouter >nul 2>&1 && sc stop AJRouter >nul 2>&1
sc query AJRouter >nul 2>&1 && sc config AJRouter start= disabled >nul 2>&1
exit /b 0
