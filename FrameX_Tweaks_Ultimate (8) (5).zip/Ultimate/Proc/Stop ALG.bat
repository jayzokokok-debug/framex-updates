@echo off
sc query ALG >nul 2>&1 && sc stop ALG >nul 2>&1
sc query ALG >nul 2>&1 && sc config ALG start= disabled >nul 2>&1
exit /b 0
