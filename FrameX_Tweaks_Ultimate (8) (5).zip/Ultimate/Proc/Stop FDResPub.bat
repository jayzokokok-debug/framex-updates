@echo off
sc query FDResPub >nul 2>&1 && sc stop FDResPub >nul 2>&1
sc query FDResPub >nul 2>&1 && sc config FDResPub start= disabled >nul 2>&1
exit /b 0
