@echo off
sc query vmickvpexchange >nul 2>&1 && sc stop vmickvpexchange >nul 2>&1
sc query vmickvpexchange >nul 2>&1 && sc config vmickvpexchange start= disabled >nul 2>&1
exit /b 0
