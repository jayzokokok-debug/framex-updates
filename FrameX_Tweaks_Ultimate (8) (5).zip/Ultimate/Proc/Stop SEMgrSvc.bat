@echo off
sc query SEMgrSvc >nul 2>&1 && sc stop SEMgrSvc >nul 2>&1
sc query SEMgrSvc >nul 2>&1 && sc config SEMgrSvc start= disabled >nul 2>&1
exit /b 0
