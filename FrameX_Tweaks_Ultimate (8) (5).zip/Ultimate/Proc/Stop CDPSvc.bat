@echo off
sc query CDPSvc >nul 2>&1 && sc stop CDPSvc >nul 2>&1
sc query CDPSvc >nul 2>&1 && sc config CDPSvc start= disabled >nul 2>&1
exit /b 0
