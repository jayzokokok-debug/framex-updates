@echo off
sc query DusmSvc >nul 2>&1 && sc stop DusmSvc >nul 2>&1
sc query DusmSvc >nul 2>&1 && sc config DusmSvc start= disabled >nul 2>&1
exit /b 0
