@echo off
sc query WbioSrvc >nul 2>&1 && sc stop WbioSrvc >nul 2>&1
sc query WbioSrvc >nul 2>&1 && sc config WbioSrvc start= disabled >nul 2>&1
exit /b 0
