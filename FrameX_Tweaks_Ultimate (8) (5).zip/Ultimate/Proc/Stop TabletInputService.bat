@echo off
sc query TabletInputService >nul 2>&1 && sc stop TabletInputService >nul 2>&1
sc query TabletInputService >nul 2>&1 && sc config TabletInputService start= disabled >nul 2>&1
exit /b 0
