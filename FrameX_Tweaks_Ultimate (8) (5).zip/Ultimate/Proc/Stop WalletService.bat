@echo off
sc query WalletService >nul 2>&1 && sc stop WalletService >nul 2>&1
sc query WalletService >nul 2>&1 && sc config WalletService start= disabled >nul 2>&1
exit /b 0
