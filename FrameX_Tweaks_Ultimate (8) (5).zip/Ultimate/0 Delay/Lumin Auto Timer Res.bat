@echo off
title FRAMEX TWEAKS - Timer Resolution
color 0D
echo.
echo    ========================================
echo              FRAMEX TWEAKS
echo         LUMIN AUTO TIMER RES
echo    ========================================
echo.
net session >nul 2>&1
if not %errorlevel%==0 (
  echo    Run the panel as administrator first.
  pause
  exit /b 1
)
echo    Allowing timer resolution requests...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v GlobalTimerResolutionRequests /t REG_DWORD /d 1 /f
if not exist C:\Lumin mkdir C:\Lumin
if not exist "C:\Lumin\MeasureSleep.exe" (
  echo    Downloading MeasureSleep...
  curl -L "https://www.dropbox.com/scl/fi/35h9ds3zrl4l9xwq2g1y4/MeasureSleep.exe?rlkey=qtk1dvmtfut33npme6xw3v8pz&st=rmfboiro&dl=1" -o "C:\Lumin\MeasureSleep.exe"
)
if not exist "C:\Lumin\SetTimerResolution.exe" (
  echo    Downloading SetTimerResolution...
  curl -L "https://www.dropbox.com/scl/fi/fll2790szt3gonr0t0ow3/SetTimerResolution.exe?rlkey=5vt12ip075xtbvm1hr4iot73g&st=t2tnh3ev&dl=1" -o "C:\Lumin\SetTimerResolution.exe"
)
if not exist "C:\Lumin\SetTimerResolution.exe" (
  echo    Download failed. Check your internet and run this again.
  pause
  exit /b 1
)
:ask
set "TIMERRESVALUE="
set /p TIMERRESVALUE=Timer value in 100-ns units, 5000 or higher:
if "%TIMERRESVALUE%"=="" goto ask
echo %TIMERRESVALUE%| findstr /r "^[0-9][0-9]*$" >nul || goto ask
if %TIMERRESVALUE% LSS 5000 goto ask
set "confirm="
set /p confirm=Use %TIMERRESVALUE%? Y or N:
if /i "%confirm%"=="n" goto ask
if /i not "%confirm%"=="y" goto ask
powershell -NoProfile -Command "$s=New-Object -ComObject WScript.Shell; $sc=$s.CreateShortcut([Environment]::GetFolderPath('Startup')+'\SetTimerResolution.lnk'); $sc.TargetPath='C:\Lumin\SetTimerResolution.exe'; $sc.Arguments='--resolution %TIMERRESVALUE% --no-console'; $sc.WorkingDirectory='C:\Lumin'; $sc.Save()"
echo.
echo    Startup shortcut set to %TIMERRESVALUE%.
echo    Restart the PC so it applies.
pause
exit /b 0
