@echo off
:: Run as Administrator. Puts the services from "Extra Service Cut" back to Windows defaults.
net session >nul 2>&1 || (echo Right-click this file and choose Run as administrator. & pause & exit /b 1)
for %%S in (lfsvc SEMgrSvc WalletService CertPropSvc ScDeviceEnum SmsRouter lltdsvc CscService workfolderssvc AssignedAccessManagerSvc AxInstSV Netlogon WebClient Wecsvc fhsvc SDRSVC TroubleshootingSvc) do (
  sc query %%S >nul 2>&1 && (sc config %%S start= demand >nul 2>&1 & echo   restored %%S)
)
sc query NvTelemetryContainer >nul 2>&1 && (sc config NvTelemetryContainer start= auto >nul 2>&1 & echo   restored NvTelemetryContainer)
echo Done. Restart your PC.
pause
