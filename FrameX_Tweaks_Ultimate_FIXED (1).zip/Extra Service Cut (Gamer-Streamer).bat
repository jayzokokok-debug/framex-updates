@echo off
:: Run as Administrator. Disables extra services that are safe for gaming + streaming.
:: Everything here is skipped automatically if it doesn't exist on your PC.
:: Undo with "Undo Extra Service Cut.bat". Restart afterwards.
net session >nul 2>&1 || (echo Right-click this file and choose Run as administrator. & pause & exit /b 1)
echo Disabling extra services...
for %%S in (lfsvc SEMgrSvc WalletService CertPropSvc ScDeviceEnum SmsRouter lltdsvc CscService workfolderssvc AssignedAccessManagerSvc AxInstSV Netlogon WebClient Wecsvc fhsvc SDRSVC TroubleshootingSvc NvTelemetryContainer) do (
  sc query %%S >nul 2>&1 && (sc stop %%S >nul 2>&1 & sc config %%S start= disabled >nul 2>&1 & echo   disabled %%S)
)
echo.
echo Done. Restart your PC, then check Task Manager - Details after 2 minutes.
pause
